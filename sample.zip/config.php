<?php

// $sql = mysqli_connect("localhost", "myproje1_petapp", "-K4I0V_LCHj{", "myproje1_petapp");
$sql = mysqli_connect("localhost", "root", "", "myproje1_northstar");
// $sql = mysqli_connect("localhost", "myproje1", "G7V@6FUt[t2e5m", "myproje1_creative");
// date_default_timezone_set("Asia/Kolkata");
// ini_set('display_errors', '1');
// ini_set('display_startup_errors', '1');
// error_reporting(E_ALL);
// session_start();
// session_unset();
// session_destroy();
include('modal/logout/time.php');

// >

// echo '<pre>';
// var_dump($_SESSION);
// echo '</pre>';

// if($sql){
//     echo 'Con';
// }else{
//     echo 'No';
// }
